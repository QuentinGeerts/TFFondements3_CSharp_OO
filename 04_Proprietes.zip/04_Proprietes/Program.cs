﻿using _04_Proprietes;

Personne p1 = new Personne();
Personne p2 = new Personne();

//p1.setId(1);
//p1.setAge(23);
//p1.setName("Quentin");


p1.Age = -4;
p1.Name = "Quentin";

Console.WriteLine(p1.Id);
Console.WriteLine(p1.Age);
Console.WriteLine(p1.Name);

//Console.WriteLine(p1.getName());
//Console.WriteLine(p1.getAge());
